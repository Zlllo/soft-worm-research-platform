"""Fixed two-shard execution; all fitting finishes before fresh-case viewing."""
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
specs={'rates':['real8','rewired8-11','rewired8-22','rewired8-33'],
       'grus':['gru2','gru3','gru16']}
plan=dict(status='predeclared_joint_run',models=specs,seeds=[7,17,27],episodes_per_field=[4,16,64],
          updates=[512,2048],new_case_seeds=[9301,9302,9303,9304],
          fitting_before_any_new_case_evaluation=True,parallel_workers=2,
          inherited_endpoints='Exact prior 512 and selected 2048 fits reused; only missing fits generated.',
          comparison_scope='Full learned input/output; chemical layout, capacity and optimizer budgets, not biological reconstruction.')
plan_path=out/'joint-design.json'
if plan_path.exists():raise RuntimeError('joint design exists; inspect worker resume states')
plan_path.write_text(json.dumps(plan,indent=2)+'\n')
env=dict(os.environ,PYTHONPATH='src',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')

def worker(name,stage):
    command=[sys.executable,'-u','analysis/tracking_learning_surface.py','--output',str(out/name),
             '--models',*specs[name],'--stage',stage]
    with (out/(name+'-'+stage+'.log')).open('w') as log:
        subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    return name

for stage in ['fit','evaluate']:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures={pool.submit(worker,name,stage):name for name in specs}
        for future in concurrent.futures.as_completed(futures):
            print(stage,future.result(),'complete',flush=True)
    (out/'execution-state.json').write_text(json.dumps(dict(completed_stage=stage),indent=2)+'\n')
print('ALL SURFACE FITTING AND FRESH-CASE CHECKS COMPLETE',flush=True)
