"""Short post-design diagnostic, not a new training condition.

FeatureCircuit neural-state oddness under whole-history sign reversal, and
initial paired-batch MSE gradients for an even (absolute-error) teacher target.
No optimizer steps are performed; original training files are not modified.
"""
from pathlib import Path
from dataclasses import replace
import hashlib,json,sys
import numpy as np
import torch

ROOT=Path('/Users/zzz/Desktop/软体线虫')
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'analysis'))
from connectome_pilot import Task
from connectome_memory_probe import teacher_data
from thermotaxis.connectome import load_connectome,CORE
from thermotaxis.encoding_policies import make_encoded_policy

def main():
 torch.set_num_threads(1)
 out=ROOT/'results/encoding-topology-2026-10-24'
 design=json.loads((out/'design.json').read_text())
 sources=design['source_sha256']
 unchanged={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha for p,sha in sources.items()}
 if not all(unchanged.values()): raise RuntimeError('training source differs from frozen design')
 graph=load_connectome().select(CORE)
 x,y=teacher_data(replace(Task(),batch=8),86001)
 batch=x.shape[1]
 paired=torch.cat((x,-x),dim=1);labels=torch.cat((y,y),dim=1)
 rows=[]
 for architecture in ['anatomical','dense','rewired']:
  for encoding in ['raw','adaptive']:
   torch.manual_seed(7)
   m=make_encoded_policy(graph,architecture,encoding,10001)
   h=torch.zeros(2*batch,m.size)
   neural_odd=0.;filter_odd=0.;pred=[]
   for obs in paired:
    p,_,h=m(obs,h);pred.append(p)
    neural_odd=max(neural_odd,float((h[:batch,:m.core.size]+h[batch:,:m.core.size]).abs().max().detach()))
    filter_odd=max(filter_odd,float((h[:batch,-3:-1]+h[batch:,-3:-1]).abs().max().detach()))
   pred=torch.stack(pred)
   loss=(((pred-labels)/.4)**2).mean();loss.backward()
   grads={n:None if p.grad is None else float(p.grad.detach().abs().max()) for n,p in m.named_parameters()}
   row=dict(architecture=architecture,encoding=encoding,paired_episodes=2*batch,steps=len(x),seed=7,topology_seed=10001,
      neural_state_oddness_max_abs_error=neural_odd,filter_state_oddness_max_abs_error=filter_odd,
      teacher_label_pair_max_abs_difference=float((labels[:,:batch]-labels[:,batch:]).abs().max()),
      prediction_pair_max_abs_difference=float((pred[:,:batch]-pred[:,batch:]).abs().max().detach()),
      actor_weight_gradient_max_abs=grads['core.actor.weight'],actor_bias_gradient=float(m.core.actor.bias.grad.item()),
      shared_neural_gradient_max_abs=max(v or 0. for n,v in grads.items() if not n.startswith('core.actor.')),
      all_parameter_gradient_max_abs=grads)
   rows.append(row)
   print(json.dumps({k:v for k,v in row.items() if k!='all_parameter_gradient_max_abs'}),flush=True)
 report=dict(status='post_design_initialization_symmetry_diagnostic_not_training',source_sha256=sources,source_hashes_match_frozen_design=unchanged,
   diagnostic_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dataset_seed=86001,
   construction='8 teacher trajectories duplicated with whole signed temperature history negated; identical teacher probability labels; no optimizer steps',
   interpretation=['FeatureCircuit with zero neuronal bias, odd tanh, linear gap diffusion is odd in signed history at initialization',
      'With zero actor weight and equal targets for sign-paired histories, actor-weight gradients cancel in exact arithmetic and neural gradients are zero; actor bias has a mean-error gradient',
      'Floating summation may leave tiny actor-weight gradient residuals',
      'Not proof of a unique cause of observed training failure; unpaired finite training batches break exact symmetry and learned biases can break oddness',
      'Applies to these simplified rate dynamics independent of chemical topology; not a claim about living AFD neurons or generic GRU'],rows=rows)
 target=out/'initialization_symmetry_diagnostic.json'
 if target.exists(): raise RuntimeError('refusing to overwrite existing diagnostic')
 target.write_text(json.dumps(report,indent=2)+'\n')
 snapshot=out/'source/diagnostics/initialization_symmetry_probe.py';snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(Path(__file__).read_bytes())
 print('SAVED',str(target),flush=True)

if __name__=='__main__':main()
