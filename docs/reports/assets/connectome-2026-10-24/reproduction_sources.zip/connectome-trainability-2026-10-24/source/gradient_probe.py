from pathlib import Path
import sys,json
sys.path.insert(0,'src');sys.path.insert(0,'analysis')
import numpy as np,torch
from connectome_pilot import Task,PointBatch
from thermotaxis.connectome import load_connectome,CORE
from thermotaxis.connectome_policy import CircuitPolicy,GenericGRUPolicy
OUT=Path('results/connectome-trainability-2026-10-24')
torch.set_num_threads(1)
rows=[]
for variant in ['generic_gru','anatomical']:
 for stage in ['initial','final']:
  torch.manual_seed(7)
  model=GenericGRUPolicy() if variant=='generic_gru' else CircuitPolicy(load_connectome().select(CORE))
  if stage=='final': model.load_state_dict(torch.load(OUT/f'{variant}-7.pt',weights_only=True))
  t=Task();env=PointBatch(t,1007);env.reset();h=torch.zeros(t.batch,model.size)
  logs=[];values=[];rewards=[];entropies=[];states=[]
  for _ in range(t.steps):
   p,v,h=model(env.observation(),h);states.append(h)
   dist=torch.distributions.Bernoulli(probs=p)
   a=torch.tensor(env.action_rng.random(t.batch)<p.detach().numpy(),dtype=torch.float32)
   r,_=env.step(a.numpy().astype(bool));logs.append(dist.log_prob(a));values.append(v);rewards.append(torch.tensor(r,dtype=torch.float32));entropies.append(dist.entropy())
  values=torch.stack(values);rewards=torch.stack(rewards);advantages=torch.zeros_like(rewards);gae=torch.zeros(t.batch);following=torch.zeros(t.batch)
  for k in reversed(range(t.steps)):
   delta=rewards[k]+.99*following-values[k].detach();gae=delta+.99*.95*gae;advantages[k]=gae;following=values[k].detach()
  targets=advantages+values.detach();normalized=(advantages-advantages.mean())/(advantages.std()+1e-8)
  actor=-(torch.stack(logs)*normalized).mean();critic=.5*(values-targets).square().mean();entropy=-.01*torch.stack(entropies).mean()
  recurrent=[p for name,p in model.named_parameters() if not name.startswith(('actor','critic'))]
  norms={}
  for name,loss in [('actor',actor),('critic',critic),('entropy',entropy)]:
   grads=torch.autograd.grad(loss,recurrent,retain_graph=True,allow_unused=True)
   norms[name]=float(torch.sqrt(sum((g*g).sum() for g in grads if g is not None)))
  states=torch.stack(states)
  rows.append(dict(variant=variant,stage=stage,shared_gradient_norm=norms,loss=dict(actor=float(actor.detach()),critic=float(critic.detach()),entropy=float(entropy.detach())),hidden_abs_mean=float(states.abs().mean().detach()),hidden_saturation_fraction=float((states.abs()>.95).float().mean()),critic_value_mean=float(values.mean().detach()),target_mean=float(targets.mean())))
print(json.dumps(rows,indent=2));(OUT/'gradient_diagnostics.json').write_text(json.dumps(rows,indent=2)+'\n')
