from pathlib import Path
from dataclasses import asdict, replace
import hashlib, json, shutil, subprocess, sys, time
import numpy as np
import torch

ROOT=Path('/Users/zzz/Desktop/软体线虫')
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'analysis'))
from connectome_pilot import Task, PointBatch, evaluate, train_one
from thermotaxis.connectome import load_connectome, CORE

OUT=ROOT/'results/connectome-trainability-2026-10-24'
if OUT.exists():
    raise RuntimeError('Refusing to overwrite existing trainability directory')
OUT.mkdir(parents=True)
SOURCES=['analysis/connectome_pilot.py','src/thermotaxis/connectome.py','src/thermotaxis/connectome_policy.py']
sha={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in SOURCES}
for p in SOURCES:
    target=OUT/'source'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,target)
shutil.copyfile(__file__,OUT/'source/trainability_probe.py')
torch.set_num_threads(1)
task=Task(); graph=load_connectome().select(CORE)
design=dict(status='exploratory_trainability_probe',created_unix=time.time(),budget=dict(variants=['generic_gru','anatomical'],seed=7,updates=512,eval_every=64,interactions_per_variant=512*task.steps*task.batch),task=asdict(task),source_sha256=sha,git_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),data=graph.provenance,versions=dict(python=sys.version,torch=torch.__version__,numpy=np.__version__),interpretation='Single seed preplanned larger-budget trainability probe; not biological superiority or sample-efficiency evidence')
(OUT/'design.json').write_text(json.dumps(design,indent=2)+'\n')

def probability_diagnostics(model):
    t=replace(task,batch=256)
    env=PointBatch(t,92001);h=torch.zeros(t.batch,model.size)
    p_all=[];delta_all=[];err_all=[];previous=np.abs(env.x*env.gradient)
    with torch.no_grad():
        for i in range(t.steps):
            p,_,h=model(env.observation(),h)
            p=p.numpy();current=np.abs(env.x*env.gradient)
            if i > 0:
                p_all.append(p);delta_all.append(current-previous);err_all.append(current)
            previous=current
            env.step(env.action_rng.random(t.batch)<p)
    p=np.asarray(p_all);delta=np.asarray(delta_all);err=np.asarray(err_all)
    result=dict(mean_probability=float(p.mean()),std_probability=float(p.std()),mean_rate_equivalent=float((-np.log1p(-p)/t.dt_s).mean()),mean_p_improving=float(p[delta<-.0001].mean()),mean_p_worsening=float(p[delta>.0001].mean()),mean_p_inside_comfort=float(p[err<=t.comfort_K].mean()) if np.any(err<=t.comfort_K) else None,mean_p_outside_comfort=float(p[err>t.comfort_K].mean()))
    histories={}
    with torch.no_grad():
        for label,start in [('improving',1.),('worsening',.1)]:
            h=torch.zeros(1,model.size)
            series=[start]*30+np.linspace(start,.5,30).tolist()
            for value in series:
                prob,_,h=model(torch.tensor([value],dtype=torch.float32),h)
            histories[label]=dict(final_observation=.5,final_probability=float(prob.item()),final_hidden=h[0].tolist())
    result['same_current_opposite_history']=histories
    return result

results=dict(design=design,baselines={name:evaluate(name,replace(task,batch=64),90001) for name in ['blind','memory']},runs=[])
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
for variant in design['budget']['variants']:
    model,run=train_one(graph,variant,7,512,task,eval_every=64)
    torch.save(model.state_dict(),OUT/f'{variant}-7.pt')
    run['probability_diagnostics']=probability_diagnostics(model)
    results['runs'].append(run)
    results['source_hashes_unchanged_at_save']={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha[p] for p in SOURCES}
    (OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print('FINISHED',variant,json.dumps(dict(curves=[{k:v for k,v in c.items() if k in ['update','interactions','residence_fraction','mean_absolute_error_K']} for c in run['curves']],diagnostics=run['probability_diagnostics'])),flush=True)
print('COMPLETE',str(OUT),flush=True)
