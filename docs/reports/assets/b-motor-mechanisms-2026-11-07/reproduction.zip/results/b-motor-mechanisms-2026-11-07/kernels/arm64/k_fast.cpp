/* Created by Language version: 7.7.0 */
/* VECTORIZED */
#define NRN_VECTORIZED 1
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mech_api.h"
#undef PI
#define nil 0
#define _pval pval
// clang-format off
#include "md1redef.h"
#include "section_fwd.hpp"
#include "nrniv_mf.h"
#include "md2redef.h"
#include "nrnconf.h"
// clang-format on
#include "neuron/cache/mechanism_range.hpp"
static constexpr auto number_of_datum_variables = 2;
static constexpr auto number_of_floating_point_variables = 43;
namespace {
template <typename T>
using _nrn_mechanism_std_vector = std::vector<T>;
using _nrn_model_sorted_token = neuron::model_sorted_token;
using _nrn_mechanism_cache_range = neuron::cache::MechanismRange<number_of_floating_point_variables, number_of_datum_variables>;
using _nrn_mechanism_cache_instance = neuron::cache::MechanismInstance<number_of_floating_point_variables, number_of_datum_variables>;
using _nrn_non_owning_id_without_container = neuron::container::non_owning_identifier_without_container;
template <typename T>
using _nrn_mechanism_field = neuron::mechanism::field<T>;
template <typename... Args>
void _nrn_mechanism_register_data_fields(Args&&... args) {
  neuron::mechanism::register_data_fields(std::forward<Args>(args)...);
}
}
 
#if !NRNGPU
#undef exp
#define exp hoc_Exp
#if NRN_ENABLE_ARCH_INDEP_EXP_POW
#undef pow
#define pow hoc_pow
#endif
#endif
 
#define nrn_init _nrn_init__k_fast
#define _nrn_initial _nrn_initial__k_fast
#define nrn_cur _nrn_cur__k_fast
#define _nrn_current _nrn_current__k_fast
#define nrn_jacob _nrn_jacob__k_fast
#define nrn_state _nrn_state__k_fast
#define _net_receive _net_receive__k_fast 
#define rates rates__k_fast 
#define states states__k_fast 
 
#define _threadargscomma_ _ml, _iml, _ppvar, _thread, _globals, _nt,
#define _threadargsprotocomma_ Memb_list* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt,
#define _internalthreadargsprotocomma_ _nrn_mechanism_cache_range* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt,
#define _threadargs_ _ml, _iml, _ppvar, _thread, _globals, _nt
#define _threadargsproto_ Memb_list* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt
#define _internalthreadargsproto_ _nrn_mechanism_cache_range* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *hoc_getarg(int);
 
#define t _nt->_t
#define dt _nt->_dt
#define gmax _ml->template fpfield<0>(_iml)
#define gmax_columnindex 0
#define conductance _ml->template fpfield<1>(_iml)
#define conductance_columnindex 1
#define p_instances _ml->template fpfield<2>(_iml)
#define p_instances_columnindex 2
#define p_timeCourse_tau _ml->template fpfield<3>(_iml)
#define p_timeCourse_tau_columnindex 3
#define p_steadyState_rate _ml->template fpfield<4>(_iml)
#define p_steadyState_rate_columnindex 4
#define p_steadyState_midpoint _ml->template fpfield<5>(_iml)
#define p_steadyState_midpoint_columnindex 5
#define p_steadyState_scale _ml->template fpfield<6>(_iml)
#define p_steadyState_scale_columnindex 6
#define q_instances _ml->template fpfield<7>(_iml)
#define q_instances_columnindex 7
#define q_timeCourse_tau _ml->template fpfield<8>(_iml)
#define q_timeCourse_tau_columnindex 8
#define q_steadyState_rate _ml->template fpfield<9>(_iml)
#define q_steadyState_rate_columnindex 9
#define q_steadyState_midpoint _ml->template fpfield<10>(_iml)
#define q_steadyState_midpoint_columnindex 10
#define q_steadyState_scale _ml->template fpfield<11>(_iml)
#define q_steadyState_scale_columnindex 11
#define gion _ml->template fpfield<12>(_iml)
#define gion_columnindex 12
#define i__k_fast _ml->template fpfield<13>(_iml)
#define i__k_fast_columnindex 13
#define p_timeCourse_t _ml->template fpfield<14>(_iml)
#define p_timeCourse_t_columnindex 14
#define p_steadyState_x _ml->template fpfield<15>(_iml)
#define p_steadyState_x_columnindex 15
#define p_rateScale _ml->template fpfield<16>(_iml)
#define p_rateScale_columnindex 16
#define p_fcond _ml->template fpfield<17>(_iml)
#define p_fcond_columnindex 17
#define p_inf _ml->template fpfield<18>(_iml)
#define p_inf_columnindex 18
#define p_tauUnscaled _ml->template fpfield<19>(_iml)
#define p_tauUnscaled_columnindex 19
#define p_tau _ml->template fpfield<20>(_iml)
#define p_tau_columnindex 20
#define q_timeCourse_t _ml->template fpfield<21>(_iml)
#define q_timeCourse_t_columnindex 21
#define q_steadyState_x _ml->template fpfield<22>(_iml)
#define q_steadyState_x_columnindex 22
#define q_rateScale _ml->template fpfield<23>(_iml)
#define q_rateScale_columnindex 23
#define q_fcond _ml->template fpfield<24>(_iml)
#define q_fcond_columnindex 24
#define q_inf _ml->template fpfield<25>(_iml)
#define q_inf_columnindex 25
#define q_tauUnscaled _ml->template fpfield<26>(_iml)
#define q_tauUnscaled_columnindex 26
#define q_tau _ml->template fpfield<27>(_iml)
#define q_tau_columnindex 27
#define conductanceScale _ml->template fpfield<28>(_iml)
#define conductanceScale_columnindex 28
#define fopen0 _ml->template fpfield<29>(_iml)
#define fopen0_columnindex 29
#define fopen _ml->template fpfield<30>(_iml)
#define fopen_columnindex 30
#define g _ml->template fpfield<31>(_iml)
#define g_columnindex 31
#define p_q _ml->template fpfield<32>(_iml)
#define p_q_columnindex 32
#define q_q _ml->template fpfield<33>(_iml)
#define q_q_columnindex 33
#define temperature _ml->template fpfield<34>(_iml)
#define temperature_columnindex 34
#define ek _ml->template fpfield<35>(_iml)
#define ek_columnindex 35
#define ik _ml->template fpfield<36>(_iml)
#define ik_columnindex 36
#define rate_p_q _ml->template fpfield<37>(_iml)
#define rate_p_q_columnindex 37
#define rate_q_q _ml->template fpfield<38>(_iml)
#define rate_q_q_columnindex 38
#define Dp_q _ml->template fpfield<39>(_iml)
#define Dp_q_columnindex 39
#define Dq_q _ml->template fpfield<40>(_iml)
#define Dq_q_columnindex 40
#define v _ml->template fpfield<41>(_iml)
#define v_columnindex 41
#define _g _ml->template fpfield<42>(_iml)
#define _g_columnindex 42
#define _ion_ik *(_ml->dptr_field<0>(_iml))
#define _p_ion_ik static_cast<neuron::container::data_handle<double>>(_ppvar[0])
#define _ion_dikdv *(_ml->dptr_field<1>(_iml))
 /* Thread safe. No static _ml, _iml or _ppvar. */
 static int hoc_nrnpointerindex =  -1;
 static _nrn_mechanism_std_vector<Datum> _extcall_thread;
 static Prop* _extcall_prop;
 /* _prop_id kind of shadows _extcall_prop to allow validity checking. */
 static _nrn_non_owning_id_without_container _prop_id{};
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static void _hoc_rates(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
 
#define NMODL_TEXT 1
#if NMODL_TEXT
static void register_nmodl_text_and_filename(int mechtype);
#endif
 static void _hoc_setdata();
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 {"setdata_k_fast", _hoc_setdata},
 {"rates_k_fast", _hoc_rates},
 {0, 0}
};
 
/* Direct Python call wrappers to density mechanism functions.*/
 static double _npy_rates(Prop*);
 
static NPyDirectMechFunc npy_direct_func_proc[] = {
 {"rates", _npy_rates},
 {0, 0}
};
 /* declare global and static user variables */
 #define gind 0
 #define _gth 0
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 {0, 0, 0}
};
 static HocParmUnits _hoc_parm_units[] = {
 {"gmax_k_fast", "S/cm2"},
 {"conductance_k_fast", "uS"},
 {"p_timeCourse_tau_k_fast", "ms"},
 {"p_steadyState_midpoint_k_fast", "mV"},
 {"p_steadyState_scale_k_fast", "mV"},
 {"q_timeCourse_tau_k_fast", "ms"},
 {"q_steadyState_midpoint_k_fast", "mV"},
 {"q_steadyState_scale_k_fast", "mV"},
 {"gion_k_fast", "S/cm2"},
 {"i__k_fast_k_fast", "mA/cm2"},
 {"p_timeCourse_t_k_fast", "ms"},
 {"p_tauUnscaled_k_fast", "ms"},
 {"p_tau_k_fast", "ms"},
 {"q_timeCourse_t_k_fast", "ms"},
 {"q_tauUnscaled_k_fast", "ms"},
 {"q_tau_k_fast", "ms"},
 {"g_k_fast", "uS"},
 {0, 0}
};
 static double delta_t = 0.01;
 static double p_q0 = 0;
 static double q_q0 = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 {0, 0}
};
 static DoubVec hoc_vdoub[] = {
 {0, 0, 0}
};
 static double _sav_indep;
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _extcall_prop = _prop;
 _prop_id = _nrn_get_prop_id(_prop);
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 static void nrn_alloc(Prop*);
static void nrn_init(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void nrn_state(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 static void nrn_cur(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void nrn_jacob(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(Prop*, int, neuron::container::data_handle<double>*, neuron::container::data_handle<double>*, double*, int);
static void _ode_spec(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void _ode_matsol(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 
#define _cvode_ieq _ppvar[2].literal_value<int>()
 static void _ode_matsol_instance1(_internalthreadargsproto_);
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "7.7.0",
"k_fast",
 "gmax_k_fast",
 "conductance_k_fast",
 "p_instances_k_fast",
 "p_timeCourse_tau_k_fast",
 "p_steadyState_rate_k_fast",
 "p_steadyState_midpoint_k_fast",
 "p_steadyState_scale_k_fast",
 "q_instances_k_fast",
 "q_timeCourse_tau_k_fast",
 "q_steadyState_rate_k_fast",
 "q_steadyState_midpoint_k_fast",
 "q_steadyState_scale_k_fast",
 0,
 "gion_k_fast",
 "i__k_fast_k_fast",
 "p_timeCourse_t_k_fast",
 "p_steadyState_x_k_fast",
 "p_rateScale_k_fast",
 "p_fcond_k_fast",
 "p_inf_k_fast",
 "p_tauUnscaled_k_fast",
 "p_tau_k_fast",
 "q_timeCourse_t_k_fast",
 "q_steadyState_x_k_fast",
 "q_rateScale_k_fast",
 "q_fcond_k_fast",
 "q_inf_k_fast",
 "q_tauUnscaled_k_fast",
 "q_tau_k_fast",
 "conductanceScale_k_fast",
 "fopen0_k_fast",
 "fopen_k_fast",
 "g_k_fast",
 0,
 "p_q_k_fast",
 "q_q_k_fast",
 0,
 0};
 static Symbol* _k_sym;
 
 /* Used by NrnProperty */
 static _nrn_mechanism_std_vector<double> _parm_default{
     0, /* gmax */
     1e-05, /* conductance */
     4, /* p_instances */
     2.25518, /* p_timeCourse_tau */
     1, /* p_steadyState_rate */
     -8.05232, /* p_steadyState_midpoint */
     7.42636, /* p_steadyState_scale */
     1, /* q_instances */
     149.963, /* q_timeCourse_tau */
     1, /* q_steadyState_rate */
     -15.6456, /* q_steadyState_midpoint */
     -9.97468, /* q_steadyState_scale */
 }; 
 
 
extern Prop* need_memb(Symbol*);
static void nrn_alloc(Prop* _prop) {
  Prop *prop_ion{};
  Datum *_ppvar{};
   _ppvar = nrn_prop_datum_alloc(_mechtype, 3, _prop);
    _nrn_mechanism_access_dparam(_prop) = _ppvar;
     _nrn_mechanism_cache_instance _ml_real{_prop};
    auto* const _ml = &_ml_real;
    size_t const _iml{};
    assert(_nrn_mechanism_get_num_vars(_prop) == 43);
 	/*initialize range parameters*/
 	gmax = _parm_default[0]; /* 0 */
 	conductance = _parm_default[1]; /* 1e-05 */
 	p_instances = _parm_default[2]; /* 4 */
 	p_timeCourse_tau = _parm_default[3]; /* 2.25518 */
 	p_steadyState_rate = _parm_default[4]; /* 1 */
 	p_steadyState_midpoint = _parm_default[5]; /* -8.05232 */
 	p_steadyState_scale = _parm_default[6]; /* 7.42636 */
 	q_instances = _parm_default[7]; /* 1 */
 	q_timeCourse_tau = _parm_default[8]; /* 149.963 */
 	q_steadyState_rate = _parm_default[9]; /* 1 */
 	q_steadyState_midpoint = _parm_default[10]; /* -15.6456 */
 	q_steadyState_scale = _parm_default[11]; /* -9.97468 */
 	 assert(_nrn_mechanism_get_num_vars(_prop) == 43);
 	_nrn_mechanism_access_dparam(_prop) = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_k_sym);
 	_ppvar[0] = _nrn_mechanism_get_param_handle(prop_ion, 3); /* ik */
 	_ppvar[1] = _nrn_mechanism_get_param_handle(prop_ion, 4); /* _ion_dikdv */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 {0, 0}
};
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*)(Datum*));
void _nrn_thread_table_reg(int, nrn_thread_table_check_t);
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 extern "C" void _k_fast_reg() {
	int _vectorized = 1;
  _initlists();
 	ion_reg("k", 1.0);
 	_k_sym = hoc_lookup("k_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 1);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
 hoc_register_parm_default(_mechtype, &_parm_default);
         hoc_register_npy_direct(_mechtype, npy_direct_func_proc);
     _nrn_setdata_reg(_mechtype, _setdata);
 #if NMODL_TEXT
  register_nmodl_text_and_filename(_mechtype);
#endif
   _nrn_mechanism_register_data_fields(_mechtype,
                                       _nrn_mechanism_field<double>{"gmax"} /* 0 */,
                                       _nrn_mechanism_field<double>{"conductance"} /* 1 */,
                                       _nrn_mechanism_field<double>{"p_instances"} /* 2 */,
                                       _nrn_mechanism_field<double>{"p_timeCourse_tau"} /* 3 */,
                                       _nrn_mechanism_field<double>{"p_steadyState_rate"} /* 4 */,
                                       _nrn_mechanism_field<double>{"p_steadyState_midpoint"} /* 5 */,
                                       _nrn_mechanism_field<double>{"p_steadyState_scale"} /* 6 */,
                                       _nrn_mechanism_field<double>{"q_instances"} /* 7 */,
                                       _nrn_mechanism_field<double>{"q_timeCourse_tau"} /* 8 */,
                                       _nrn_mechanism_field<double>{"q_steadyState_rate"} /* 9 */,
                                       _nrn_mechanism_field<double>{"q_steadyState_midpoint"} /* 10 */,
                                       _nrn_mechanism_field<double>{"q_steadyState_scale"} /* 11 */,
                                       _nrn_mechanism_field<double>{"gion"} /* 12 */,
                                       _nrn_mechanism_field<double>{"i__k_fast"} /* 13 */,
                                       _nrn_mechanism_field<double>{"p_timeCourse_t"} /* 14 */,
                                       _nrn_mechanism_field<double>{"p_steadyState_x"} /* 15 */,
                                       _nrn_mechanism_field<double>{"p_rateScale"} /* 16 */,
                                       _nrn_mechanism_field<double>{"p_fcond"} /* 17 */,
                                       _nrn_mechanism_field<double>{"p_inf"} /* 18 */,
                                       _nrn_mechanism_field<double>{"p_tauUnscaled"} /* 19 */,
                                       _nrn_mechanism_field<double>{"p_tau"} /* 20 */,
                                       _nrn_mechanism_field<double>{"q_timeCourse_t"} /* 21 */,
                                       _nrn_mechanism_field<double>{"q_steadyState_x"} /* 22 */,
                                       _nrn_mechanism_field<double>{"q_rateScale"} /* 23 */,
                                       _nrn_mechanism_field<double>{"q_fcond"} /* 24 */,
                                       _nrn_mechanism_field<double>{"q_inf"} /* 25 */,
                                       _nrn_mechanism_field<double>{"q_tauUnscaled"} /* 26 */,
                                       _nrn_mechanism_field<double>{"q_tau"} /* 27 */,
                                       _nrn_mechanism_field<double>{"conductanceScale"} /* 28 */,
                                       _nrn_mechanism_field<double>{"fopen0"} /* 29 */,
                                       _nrn_mechanism_field<double>{"fopen"} /* 30 */,
                                       _nrn_mechanism_field<double>{"g"} /* 31 */,
                                       _nrn_mechanism_field<double>{"p_q"} /* 32 */,
                                       _nrn_mechanism_field<double>{"q_q"} /* 33 */,
                                       _nrn_mechanism_field<double>{"temperature"} /* 34 */,
                                       _nrn_mechanism_field<double>{"ek"} /* 35 */,
                                       _nrn_mechanism_field<double>{"ik"} /* 36 */,
                                       _nrn_mechanism_field<double>{"rate_p_q"} /* 37 */,
                                       _nrn_mechanism_field<double>{"rate_q_q"} /* 38 */,
                                       _nrn_mechanism_field<double>{"Dp_q"} /* 39 */,
                                       _nrn_mechanism_field<double>{"Dq_q"} /* 40 */,
                                       _nrn_mechanism_field<double>{"v"} /* 41 */,
                                       _nrn_mechanism_field<double>{"_g"} /* 42 */,
                                       _nrn_mechanism_field<double*>{"_ion_ik", "k_ion"} /* 0 */,
                                       _nrn_mechanism_field<double*>{"_ion_dikdv", "k_ion"} /* 1 */,
                                       _nrn_mechanism_field<int>{"_cvode_ieq", "cvodeieq"} /* 2 */);
  hoc_register_prop_size(_mechtype, 43, 3);
  hoc_register_dparam_semantics(_mechtype, 0, "k_ion");
  hoc_register_dparam_semantics(_mechtype, 1, "k_ion");
  hoc_register_dparam_semantics(_mechtype, 2, "cvodeieq");
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 
    hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 k_fast /Users/zzz/Desktop/软体线虫/results/full302-operating-range-2026-11-07/kernels-direct-cnexp/k_fast.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
static int _reset;
static const char *modelname = "Mod file for component: Component(id=k_fast type=ionChannelHH)";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int rates(_internalthreadargsproto_);
 
static int _ode_spec1(_internalthreadargsproto_);
/*static int _ode_matsol1(_internalthreadargsproto_);*/
 static neuron::container::field_index _slist1[2], _dlist1[2];
 static int states(_internalthreadargsproto_);
 
/*CVODE*/
 static int _ode_spec1 (_internalthreadargsproto_) {int _reset = 0; {
   rates ( _threadargs_ ) ;
   Dp_q = rate_p_q ;
   Dq_q = rate_q_q ;
   }
 return _reset;
}
 static int _ode_matsol1 (_internalthreadargsproto_) {
 rates ( _threadargs_ ) ;
 Dp_q = Dp_q  / (1. - dt*( 0.0 )) ;
 Dq_q = Dq_q  / (1. - dt*( 0.0 )) ;
  return 0;
}
 /*END CVODE*/
 static int states (_internalthreadargsproto_) { {
   rates ( _threadargs_ ) ;
    p_q = p_q - dt*(- ( rate_p_q ) ) ;
    q_q = q_q - dt*(- ( rate_q_q ) ) ;
   }
  return 0;
}
 
static int  rates ( _internalthreadargsproto_ ) {
   p_timeCourse_t = p_timeCourse_tau ;
   p_steadyState_x = p_steadyState_rate / ( 1.0 + exp ( 0.0 - ( v - p_steadyState_midpoint ) / p_steadyState_scale ) ) ;
   p_rateScale = 1.0 ;
   p_fcond = pow( p_q , p_instances ) ;
   p_inf = p_steadyState_x ;
   p_tauUnscaled = p_timeCourse_t ;
   p_tau = p_tauUnscaled / p_rateScale ;
   q_timeCourse_t = q_timeCourse_tau ;
   q_steadyState_x = q_steadyState_rate / ( 1.0 + exp ( 0.0 - ( v - q_steadyState_midpoint ) / q_steadyState_scale ) ) ;
   q_rateScale = 1.0 ;
   q_fcond = pow( q_q , q_instances ) ;
   q_inf = q_steadyState_x ;
   q_tauUnscaled = q_timeCourse_t ;
   q_tau = q_tauUnscaled / q_rateScale ;
   rate_p_q = ( p_inf - p_q ) / p_tau ;
   rate_q_q = ( q_inf - q_q ) / q_tau ;
    return 0; }
 
static void _hoc_rates(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  if(!_prop_id) {
    hoc_execerror("No data for rates_k_fast. Requires prior call to setdata_k_fast and that the specified mechanism instance still be in existence.", NULL);
  }
  Prop* _local_prop = _extcall_prop;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r = 1.;
 rates ( _threadargs_ );
 hoc_retpushx(_r);
}
 
static double _npy_rates(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r = 1.;
 rates ( _threadargs_ );
 return(_r);
}
 
static int _ode_count(int _type){ return 2;}
 
static void _ode_spec(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
   Datum* _ppvar;
   size_t _iml;   _nrn_mechanism_cache_range* _ml;   Node* _nd{};
  double _v{};
  int _cntml;
  _nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
  _ml = &_lmr;
  _cntml = _ml_arg->_nodecount;
  Datum *_thread{_ml_arg->_thread};
  double* _globals = nullptr;
  if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _ppvar = _ml_arg->_pdata[_iml];
    _nd = _ml_arg->_nodelist[_iml];
    v = NODEV(_nd);
     _ode_spec1 (_threadargs_);
  }}
 
static void _ode_map(Prop* _prop, int _ieq, neuron::container::data_handle<double>* _pv, neuron::container::data_handle<double>* _pvdot, double* _atol, int _type) { 
  Datum* _ppvar;
  _ppvar = _nrn_mechanism_access_dparam(_prop);
  _cvode_ieq = _ieq;
  for (int _i=0; _i < 2; ++_i) {
    _pv[_i] = _nrn_mechanism_get_param_handle(_prop, _slist1[_i]);
    _pvdot[_i] = _nrn_mechanism_get_param_handle(_prop, _dlist1[_i]);
    _cvode_abstol(_atollist, _atol, _i);
  }
 }
 
static void _ode_matsol_instance1(_internalthreadargsproto_) {
 _ode_matsol1 (_threadargs_);
 }
 
static void _ode_matsol(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
   Datum* _ppvar;
   size_t _iml;   _nrn_mechanism_cache_range* _ml;   Node* _nd{};
  double _v{};
  int _cntml;
  _nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
  _ml = &_lmr;
  _cntml = _ml_arg->_nodecount;
  Datum *_thread{_ml_arg->_thread};
  double* _globals = nullptr;
  if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _ppvar = _ml_arg->_pdata[_iml];
    _nd = _ml_arg->_nodelist[_iml];
    v = NODEV(_nd);
 _ode_matsol_instance1(_threadargs_);
 }}

static void initmodel(_internalthreadargsproto_) {
  int _i; double _save;{
  p_q = p_q0;
  q_q = q_q0;
 {
   ek = - 60.0 ;
   temperature = celsius + 273.15 ;
   rates ( _threadargs_ ) ;
   rates ( _threadargs_ ) ;
   p_q = p_inf ;
   q_q = q_inf ;
   }
 
}
}

static void nrn_init(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type){
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto* const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
   _v = _vec_v[_ni[_iml]];
 v = _v;
 initmodel(_threadargs_);
 }
}

static double _nrn_current(_internalthreadargsprotocomma_ double _v) {
double _current=0.; v=_v;
{ {
   conductanceScale = 1.0 ;
   fopen0 = p_fcond * q_fcond ;
   fopen = conductanceScale * fopen0 ;
   g = conductance * fopen ;
   gion = gmax * fopen ;
   ik = gion * ( v - ek ) ;
   i__k_fast = - 1.0 * ik ;
   }
 _current += ik;

} return _current;
}

static void nrn_cur(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto const _vec_rhs = _nt->node_rhs_storage();
auto const _vec_sav_rhs = _nt->node_sav_rhs_storage();
auto const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
   _v = _vec_v[_ni[_iml]];
 auto const _g_local = _nrn_current(_threadargscomma_ _v + .001);
 	{ double _dik;
  _dik = ik;
 _rhs = _nrn_current(_threadargscomma_ _v);
  _ion_dikdv += (_dik - ik)/.001 ;
 	}
 _g = (_g_local - _rhs)/.001;
  _ion_ik += ik ;
	 _vec_rhs[_ni[_iml]] -= _rhs;
 
}
 
}

static void nrn_jacob(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto const _vec_d = _nt->node_d_storage();
auto const _vec_sav_d = _nt->node_sav_d_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
  _vec_d[_ni[_iml]] += _g;
 
}
 
}

static void nrn_state(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto* const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; double _v = 0.0; int* _ni;
_ni = _ml_arg->_nodeindices;
size_t _cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (size_t _iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
 _nd = _ml_arg->_nodelist[_iml];
   _v = _vec_v[_ni[_iml]];
 v=_v;
{
 {   states(_threadargs_);
  } }}

}

static void terminal(){}

static void _initlists(){
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = {p_q_columnindex, 0};  _dlist1[0] = {Dp_q_columnindex, 0};
 _slist1[1] = {q_q_columnindex, 0};  _dlist1[1] = {Dq_q_columnindex, 0};
_first = 0;
}

#if NMODL_TEXT
static void register_nmodl_text_and_filename(int mech_type) {
    const char* nmodl_filename = "/Users/zzz/Desktop/软体线虫/results/full302-operating-range-2026-11-07/kernels-direct-cnexp/k_fast.mod";
    const char* nmodl_file_text = 
  "TITLE Mod file for component: Component(id=k_fast type=ionChannelHH)\n"
  "\n"
  "COMMENT\n"
  "\n"
  "    This NEURON file has been generated by org.neuroml.export (see https://github.com/NeuroML/org.neuroml.export)\n"
  "         org.neuroml.export  v1.11.0\n"
  "         org.neuroml.model   v1.11.0\n"
  "         jLEMS               v0.12.0\n"
  "\n"
  "ENDCOMMENT\n"
  "\n"
  "NEURON {\n"
  "    SUFFIX k_fast\n"
  "    USEION k WRITE ik VALENCE 1 ? Assuming valence = 1; TODO check this!!\n"
  "    \n"
  "    RANGE gion\n"
  "    RANGE i__k_fast : a copy of the variable for current which makes it easier to access from outside the mod file\n"
  "    RANGE gmax                              : Will be changed when ion channel mechanism placed on cell!\n"
  "    RANGE conductance                       : parameter\n"
  "    RANGE g                                 : exposure\n"
  "    RANGE fopen                             : exposure\n"
  "    RANGE p_instances                       : parameter\n"
  "    RANGE p_tau                             : exposure\n"
  "    RANGE p_inf                             : exposure\n"
  "    RANGE p_rateScale                       : exposure\n"
  "    RANGE p_fcond                           : exposure\n"
  "    RANGE p_timeCourse_tau                  : parameter\n"
  "    RANGE p_timeCourse_t                    : exposure\n"
  "    RANGE p_steadyState_rate                : parameter\n"
  "    RANGE p_steadyState_midpoint            : parameter\n"
  "    RANGE p_steadyState_scale               : parameter\n"
  "    RANGE p_steadyState_x                   : exposure\n"
  "    RANGE q_instances                       : parameter\n"
  "    RANGE q_tau                             : exposure\n"
  "    RANGE q_inf                             : exposure\n"
  "    RANGE q_rateScale                       : exposure\n"
  "    RANGE q_fcond                           : exposure\n"
  "    RANGE q_timeCourse_tau                  : parameter\n"
  "    RANGE q_timeCourse_t                    : exposure\n"
  "    RANGE q_steadyState_rate                : parameter\n"
  "    RANGE q_steadyState_midpoint            : parameter\n"
  "    RANGE q_steadyState_scale               : parameter\n"
  "    RANGE q_steadyState_x                   : exposure\n"
  "    RANGE p_tauUnscaled                     : derived variable\n"
  "    RANGE q_tauUnscaled                     : derived variable\n"
  "    RANGE conductanceScale                  : derived variable\n"
  "    RANGE fopen0                            : derived variable\n"
  "    \n"
  "}\n"
  "\n"
  "UNITS {\n"
  "    \n"
  "    (nA) = (nanoamp)\n"
  "    (uA) = (microamp)\n"
  "    (mA) = (milliamp)\n"
  "    (A) = (amp)\n"
  "    (mV) = (millivolt)\n"
  "    (mS) = (millisiemens)\n"
  "    (uS) = (microsiemens)\n"
  "    (nF) = (nanofarad)\n"
  "    (molar) = (1/liter)\n"
  "    (kHz) = (kilohertz)\n"
  "    (mM) = (millimolar)\n"
  "    (um) = (micrometer)\n"
  "    (umol) = (micromole)\n"
  "    (pC) = (picocoulomb)\n"
  "    (S) = (siemens)\n"
  "    \n"
  "}\n"
  "\n"
  "PARAMETER {\n"
  "    \n"
  "    gmax = 0  (S/cm2)                       : Will be changed when ion channel mechanism placed on cell!\n"
  "    \n"
  "    conductance = 1.0E-5 (uS)              : was: 1.0E-11 (conductance)\n"
  "    p_instances = 4                        : was: 4.0 (none)\n"
  "    p_timeCourse_tau = 2.25518 (ms)        : was: 0.0022551800000000003 (time)\n"
  "    p_steadyState_rate = 1                 : was: 1.0 (none)\n"
  "    p_steadyState_midpoint = -8.05232 (mV) : was: -0.00805232 (voltage)\n"
  "    p_steadyState_scale = 7.42636 (mV)     : was: 0.00742636 (voltage)\n"
  "    q_instances = 1                        : was: 1.0 (none)\n"
  "    q_timeCourse_tau = 149.963 (ms)        : was: 0.14996299999999999 (time)\n"
  "    q_steadyState_rate = 1                 : was: 1.0 (none)\n"
  "    q_steadyState_midpoint = -15.6456 (mV) : was: -0.0156456 (voltage)\n"
  "    q_steadyState_scale = -9.97468 (mV)    : was: -0.00997468 (voltage)\n"
  "}\n"
  "\n"
  "ASSIGNED {\n"
  "    \n"
  "    gion   (S/cm2)                          : Transient conductance density of the channel? Standard Assigned variables with ionChannel\n"
  "    v (mV)\n"
  "    celsius (degC)\n"
  "    temperature (K)\n"
  "    ek (mV)\n"
  "    ik (mA/cm2)\n"
  "    i__k_fast (mA/cm2)\n"
  "    \n"
  "    p_timeCourse_t (ms)                     : derived variable\n"
  "    p_steadyState_x                         : derived variable\n"
  "    p_rateScale                             : derived variable\n"
  "    p_fcond                                 : derived variable\n"
  "    p_inf                                   : derived variable\n"
  "    p_tauUnscaled (ms)                      : derived variable\n"
  "    p_tau (ms)                              : derived variable\n"
  "    q_timeCourse_t (ms)                     : derived variable\n"
  "    q_steadyState_x                         : derived variable\n"
  "    q_rateScale                             : derived variable\n"
  "    q_fcond                                 : derived variable\n"
  "    q_inf                                   : derived variable\n"
  "    q_tauUnscaled (ms)                      : derived variable\n"
  "    q_tau (ms)                              : derived variable\n"
  "    conductanceScale                        : derived variable\n"
  "    fopen0                                  : derived variable\n"
  "    fopen                                   : derived variable\n"
  "    g (uS)                                  : derived variable\n"
  "    rate_p_q (/ms)\n"
  "    rate_q_q (/ms)\n"
  "    \n"
  "}\n"
  "\n"
  "STATE {\n"
  "    p_q  : dimension: none\n"
  "    q_q  : dimension: none\n"
  "    \n"
  "}\n"
  "\n"
  "INITIAL {\n"
  "    ek = -60.0\n"
  "    \n"
  "    temperature = celsius + 273.15\n"
  "    \n"
  "    rates()\n"
  "    rates() ? To ensure correct initialisation.\n"
  "    \n"
  "    p_q = p_inf\n"
  "    \n"
  "    q_q = q_inf\n"
  "    \n"
  "}\n"
  "\n"
  "BREAKPOINT {\n"
  "    \n"
  "    SOLVE states METHOD cnexp\n"
  "    \n"
  "    ? DerivedVariable is based on path: conductanceScaling[*]/factor, on: Component(id=k_fast type=ionChannelHH), from conductanceScaling; null\n"
  "    ? Path not present in component, using factor: 1\n"
  "    \n"
  "    conductanceScale = 1 \n"
  "    \n"
  "    ? DerivedVariable is based on path: gates[*]/fcond, on: Component(id=k_fast type=ionChannelHH), from gates; Component(id=p type=gateHHtauInf)\n"
  "    ? multiply applied to all instances of fcond in: <gates> ([Component(id=p type=gateHHtauInf), Component(id=q type=gateHHtauInf)]))\n"
  "    fopen0 = p_fcond * q_fcond ? path based, prefix = \n"
  "    \n"
  "    fopen = conductanceScale  *  fopen0 ? evaluable\n"
  "    g = conductance  *  fopen ? evaluable\n"
  "    gion = gmax * fopen \n"
  "    \n"
  "    ik = gion * (v - ek)\n"
  "    i__k_fast =  -1 * ik : set this variable to the current also - note -1 as channel current convention for LEMS used!\n"
  "    \n"
  "}\n"
  "\n"
  "DERIVATIVE states {\n"
  "    rates()\n"
  "    p_q' = rate_p_q \n"
  "    q_q' = rate_q_q \n"
  "    \n"
  "}\n"
  "\n"
  "PROCEDURE rates() {\n"
  "    \n"
  "    p_timeCourse_t = p_timeCourse_tau ? evaluable\n"
  "    p_steadyState_x = p_steadyState_rate  / (1 + exp(0 - (v -  p_steadyState_midpoint )/ p_steadyState_scale )) ? evaluable\n"
  "    ? DerivedVariable is based on path: q10Settings[*]/q10, on: Component(id=p type=gateHHtauInf), from q10Settings; null\n"
  "    ? Path not present in component, using factor: 1\n"
  "    \n"
  "    p_rateScale = 1 \n"
  "    \n"
  "    p_fcond = p_q ^ p_instances ? evaluable\n"
  "    ? DerivedVariable is based on path: steadyState/x, on: Component(id=p type=gateHHtauInf), from steadyState; Component(id=null type=HHSigmoidVariable)\n"
  "    p_inf = p_steadyState_x ? path based, prefix = p_\n"
  "    \n"
  "    ? DerivedVariable is based on path: timeCourse/t, on: Component(id=p type=gateHHtauInf), from timeCourse; Component(id=null type=fixedTimeCourse)\n"
  "    p_tauUnscaled = p_timeCourse_t ? path based, prefix = p_\n"
  "    \n"
  "    p_tau = p_tauUnscaled  /  p_rateScale ? evaluable\n"
  "    q_timeCourse_t = q_timeCourse_tau ? evaluable\n"
  "    q_steadyState_x = q_steadyState_rate  / (1 + exp(0 - (v -  q_steadyState_midpoint )/ q_steadyState_scale )) ? evaluable\n"
  "    ? DerivedVariable is based on path: q10Settings[*]/q10, on: Component(id=q type=gateHHtauInf), from q10Settings; null\n"
  "    ? Path not present in component, using factor: 1\n"
  "    \n"
  "    q_rateScale = 1 \n"
  "    \n"
  "    q_fcond = q_q ^ q_instances ? evaluable\n"
  "    ? DerivedVariable is based on path: steadyState/x, on: Component(id=q type=gateHHtauInf), from steadyState; Component(id=null type=HHSigmoidVariable)\n"
  "    q_inf = q_steadyState_x ? path based, prefix = q_\n"
  "    \n"
  "    ? DerivedVariable is based on path: timeCourse/t, on: Component(id=q type=gateHHtauInf), from timeCourse; Component(id=null type=fixedTimeCourse)\n"
  "    q_tauUnscaled = q_timeCourse_t ? path based, prefix = q_\n"
  "    \n"
  "    q_tau = q_tauUnscaled  /  q_rateScale ? evaluable\n"
  "    \n"
  "     \n"
  "    rate_p_q = ( p_inf  -  p_q ) /  p_tau ? Note units of all quantities used here need to be consistent!\n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    rate_q_q = ( q_inf  -  q_q ) /  q_tau ? Note units of all quantities used here need to be consistent!\n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    \n"
  "}\n"
  "\n"
  ;
    hoc_reg_nmodl_filename(mech_type, nmodl_filename);
    hoc_reg_nmodl_text(mech_type, nmodl_file_text);
}
#endif
