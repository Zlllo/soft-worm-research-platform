/* Created by Language version: 7.7.0 */
/* VECTORIZED */
#define NRN_VECTORIZED 1
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mech_api.h"
#undef PI
#define nil 0
#define _pval pval
// clang-format off
#include "md1redef.h"
#include "section_fwd.hpp"
#include "nrniv_mf.h"
#include "md2redef.h"
#include "nrnconf.h"
// clang-format on
#include "neuron/cache/mechanism_range.hpp"
static constexpr auto number_of_datum_variables = 4;
static constexpr auto number_of_floating_point_variables = 55;
namespace {
template <typename T>
using _nrn_mechanism_std_vector = std::vector<T>;
using _nrn_model_sorted_token = neuron::model_sorted_token;
using _nrn_mechanism_cache_range = neuron::cache::MechanismRange<number_of_floating_point_variables, number_of_datum_variables>;
using _nrn_mechanism_cache_instance = neuron::cache::MechanismInstance<number_of_floating_point_variables, number_of_datum_variables>;
using _nrn_non_owning_id_without_container = neuron::container::non_owning_identifier_without_container;
template <typename T>
using _nrn_mechanism_field = neuron::mechanism::field<T>;
template <typename... Args>
void _nrn_mechanism_register_data_fields(Args&&... args) {
  neuron::mechanism::register_data_fields(std::forward<Args>(args)...);
}
}
 
#if !NRNGPU
#undef exp
#define exp hoc_Exp
#if NRN_ENABLE_ARCH_INDEP_EXP_POW
#undef pow
#define pow hoc_pow
#endif
#endif
 
#define nrn_init _nrn_init__ca_boyle
#define _nrn_initial _nrn_initial__ca_boyle
#define nrn_cur _nrn_cur__ca_boyle
#define _nrn_current _nrn_current__ca_boyle
#define nrn_jacob _nrn_jacob__ca_boyle
#define nrn_state _nrn_state__ca_boyle
#define _net_receive _net_receive__ca_boyle 
#define rates rates__ca_boyle 
#define states states__ca_boyle 
 
#define _threadargscomma_ _ml, _iml, _ppvar, _thread, _globals, _nt,
#define _threadargsprotocomma_ Memb_list* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt,
#define _internalthreadargsprotocomma_ _nrn_mechanism_cache_range* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt,
#define _threadargs_ _ml, _iml, _ppvar, _thread, _globals, _nt
#define _threadargsproto_ Memb_list* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt
#define _internalthreadargsproto_ _nrn_mechanism_cache_range* _ml, size_t _iml, Datum* _ppvar, Datum* _thread, double* _globals, NrnThread* _nt
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *hoc_getarg(int);
 
#define t _nt->_t
#define dt _nt->_dt
#define gmax _ml->template fpfield<0>(_iml)
#define gmax_columnindex 0
#define conductance _ml->template fpfield<1>(_iml)
#define conductance_columnindex 1
#define e_instances _ml->template fpfield<2>(_iml)
#define e_instances_columnindex 2
#define e_timeCourse_tau _ml->template fpfield<3>(_iml)
#define e_timeCourse_tau_columnindex 3
#define e_steadyState_rate _ml->template fpfield<4>(_iml)
#define e_steadyState_rate_columnindex 4
#define e_steadyState_midpoint _ml->template fpfield<5>(_iml)
#define e_steadyState_midpoint_columnindex 5
#define e_steadyState_scale _ml->template fpfield<6>(_iml)
#define e_steadyState_scale_columnindex 6
#define f_instances _ml->template fpfield<7>(_iml)
#define f_instances_columnindex 7
#define f_timeCourse_tau _ml->template fpfield<8>(_iml)
#define f_timeCourse_tau_columnindex 8
#define f_steadyState_rate _ml->template fpfield<9>(_iml)
#define f_steadyState_rate_columnindex 9
#define f_steadyState_midpoint _ml->template fpfield<10>(_iml)
#define f_steadyState_midpoint_columnindex 10
#define f_steadyState_scale _ml->template fpfield<11>(_iml)
#define f_steadyState_scale_columnindex 11
#define h_alpha _ml->template fpfield<12>(_iml)
#define h_alpha_columnindex 12
#define h_k _ml->template fpfield<13>(_iml)
#define h_k_columnindex 13
#define h_ca_half _ml->template fpfield<14>(_iml)
#define h_ca_half_columnindex 14
#define h_instances _ml->template fpfield<15>(_iml)
#define h_instances_columnindex 15
#define h_SEC _ml->template fpfield<16>(_iml)
#define h_SEC_columnindex 16
#define gion _ml->template fpfield<17>(_iml)
#define gion_columnindex 17
#define i__ca_boyle _ml->template fpfield<18>(_iml)
#define i__ca_boyle_columnindex 18
#define e_timeCourse_t _ml->template fpfield<19>(_iml)
#define e_timeCourse_t_columnindex 19
#define e_steadyState_x _ml->template fpfield<20>(_iml)
#define e_steadyState_x_columnindex 20
#define e_rateScale _ml->template fpfield<21>(_iml)
#define e_rateScale_columnindex 21
#define e_fcond _ml->template fpfield<22>(_iml)
#define e_fcond_columnindex 22
#define e_inf _ml->template fpfield<23>(_iml)
#define e_inf_columnindex 23
#define e_tauUnscaled _ml->template fpfield<24>(_iml)
#define e_tauUnscaled_columnindex 24
#define e_tau _ml->template fpfield<25>(_iml)
#define e_tau_columnindex 25
#define f_timeCourse_t _ml->template fpfield<26>(_iml)
#define f_timeCourse_t_columnindex 26
#define f_steadyState_x _ml->template fpfield<27>(_iml)
#define f_steadyState_x_columnindex 27
#define f_rateScale _ml->template fpfield<28>(_iml)
#define f_rateScale_columnindex 28
#define f_fcond _ml->template fpfield<29>(_iml)
#define f_fcond_columnindex 29
#define f_inf _ml->template fpfield<30>(_iml)
#define f_inf_columnindex 30
#define f_tauUnscaled _ml->template fpfield<31>(_iml)
#define f_tauUnscaled_columnindex 31
#define f_tau _ml->template fpfield<32>(_iml)
#define f_tau_columnindex 32
#define h_rateScale _ml->template fpfield<33>(_iml)
#define h_rateScale_columnindex 33
#define h_inf _ml->template fpfield<34>(_iml)
#define h_inf_columnindex 34
#define h_tau _ml->template fpfield<35>(_iml)
#define h_tau_columnindex 35
#define h_q _ml->template fpfield<36>(_iml)
#define h_q_columnindex 36
#define h_fcond _ml->template fpfield<37>(_iml)
#define h_fcond_columnindex 37
#define conductanceScale _ml->template fpfield<38>(_iml)
#define conductanceScale_columnindex 38
#define fopen0 _ml->template fpfield<39>(_iml)
#define fopen0_columnindex 39
#define fopen _ml->template fpfield<40>(_iml)
#define fopen_columnindex 40
#define g _ml->template fpfield<41>(_iml)
#define g_columnindex 41
#define e_q _ml->template fpfield<42>(_iml)
#define e_q_columnindex 42
#define f_q _ml->template fpfield<43>(_iml)
#define f_q_columnindex 43
#define temperature _ml->template fpfield<44>(_iml)
#define temperature_columnindex 44
#define eca _ml->template fpfield<45>(_iml)
#define eca_columnindex 45
#define ica _ml->template fpfield<46>(_iml)
#define ica_columnindex 46
#define cai _ml->template fpfield<47>(_iml)
#define cai_columnindex 47
#define cao _ml->template fpfield<48>(_iml)
#define cao_columnindex 48
#define rate_e_q _ml->template fpfield<49>(_iml)
#define rate_e_q_columnindex 49
#define rate_f_q _ml->template fpfield<50>(_iml)
#define rate_f_q_columnindex 50
#define De_q _ml->template fpfield<51>(_iml)
#define De_q_columnindex 51
#define Df_q _ml->template fpfield<52>(_iml)
#define Df_q_columnindex 52
#define v _ml->template fpfield<53>(_iml)
#define v_columnindex 53
#define _g _ml->template fpfield<54>(_iml)
#define _g_columnindex 54
#define _ion_cai *(_ml->dptr_field<0>(_iml))
#define _p_ion_cai static_cast<neuron::container::data_handle<double>>(_ppvar[0])
#define _ion_cao *(_ml->dptr_field<1>(_iml))
#define _p_ion_cao static_cast<neuron::container::data_handle<double>>(_ppvar[1])
#define _ion_ica *(_ml->dptr_field<2>(_iml))
#define _p_ion_ica static_cast<neuron::container::data_handle<double>>(_ppvar[2])
#define _ion_dicadv *(_ml->dptr_field<3>(_iml))
 /* Thread safe. No static _ml, _iml or _ppvar. */
 static int hoc_nrnpointerindex =  -1;
 static _nrn_mechanism_std_vector<Datum> _extcall_thread;
 static Prop* _extcall_prop;
 /* _prop_id kind of shadows _extcall_prop to allow validity checking. */
 static _nrn_non_owning_id_without_container _prop_id{};
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static void _hoc_rates(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
 
#define NMODL_TEXT 1
#if NMODL_TEXT
static void register_nmodl_text_and_filename(int mechtype);
#endif
 static void _hoc_setdata();
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 {"setdata_ca_boyle", _hoc_setdata},
 {"rates_ca_boyle", _hoc_rates},
 {0, 0}
};
 
/* Direct Python call wrappers to density mechanism functions.*/
 static double _npy_rates(Prop*);
 
static NPyDirectMechFunc npy_direct_func_proc[] = {
 {"rates", _npy_rates},
 {0, 0}
};
 /* declare global and static user variables */
 #define gind 0
 #define _gth 0
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 {0, 0, 0}
};
 static HocParmUnits _hoc_parm_units[] = {
 {"gmax_ca_boyle", "S/cm2"},
 {"conductance_ca_boyle", "uS"},
 {"e_timeCourse_tau_ca_boyle", "ms"},
 {"e_steadyState_midpoint_ca_boyle", "mV"},
 {"e_steadyState_scale_ca_boyle", "mV"},
 {"f_timeCourse_tau_ca_boyle", "ms"},
 {"f_steadyState_midpoint_ca_boyle", "mV"},
 {"f_steadyState_scale_ca_boyle", "mV"},
 {"h_k_ca_boyle", "mM"},
 {"h_ca_half_ca_boyle", "mM"},
 {"h_SEC_ca_boyle", "ms"},
 {"gion_ca_boyle", "S/cm2"},
 {"i__ca_boyle_ca_boyle", "mA/cm2"},
 {"e_timeCourse_t_ca_boyle", "ms"},
 {"e_tauUnscaled_ca_boyle", "ms"},
 {"e_tau_ca_boyle", "ms"},
 {"f_timeCourse_t_ca_boyle", "ms"},
 {"f_tauUnscaled_ca_boyle", "ms"},
 {"f_tau_ca_boyle", "ms"},
 {"h_tau_ca_boyle", "ms"},
 {"g_ca_boyle", "uS"},
 {0, 0}
};
 static double delta_t = 0.01;
 static double e_q0 = 0;
 static double f_q0 = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 {0, 0}
};
 static DoubVec hoc_vdoub[] = {
 {0, 0, 0}
};
 static double _sav_indep;
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _extcall_prop = _prop;
 _prop_id = _nrn_get_prop_id(_prop);
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 static void nrn_alloc(Prop*);
static void nrn_init(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void nrn_state(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 static void nrn_cur(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void nrn_jacob(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(Prop*, int, neuron::container::data_handle<double>*, neuron::container::data_handle<double>*, double*, int);
static void _ode_spec(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
static void _ode_matsol(_nrn_model_sorted_token const&, NrnThread*, Memb_list*, int);
 
#define _cvode_ieq _ppvar[4].literal_value<int>()
 static void _ode_matsol_instance1(_internalthreadargsproto_);
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "7.7.0",
"ca_boyle",
 "gmax_ca_boyle",
 "conductance_ca_boyle",
 "e_instances_ca_boyle",
 "e_timeCourse_tau_ca_boyle",
 "e_steadyState_rate_ca_boyle",
 "e_steadyState_midpoint_ca_boyle",
 "e_steadyState_scale_ca_boyle",
 "f_instances_ca_boyle",
 "f_timeCourse_tau_ca_boyle",
 "f_steadyState_rate_ca_boyle",
 "f_steadyState_midpoint_ca_boyle",
 "f_steadyState_scale_ca_boyle",
 "h_alpha_ca_boyle",
 "h_k_ca_boyle",
 "h_ca_half_ca_boyle",
 "h_instances_ca_boyle",
 "h_SEC_ca_boyle",
 0,
 "gion_ca_boyle",
 "i__ca_boyle_ca_boyle",
 "e_timeCourse_t_ca_boyle",
 "e_steadyState_x_ca_boyle",
 "e_rateScale_ca_boyle",
 "e_fcond_ca_boyle",
 "e_inf_ca_boyle",
 "e_tauUnscaled_ca_boyle",
 "e_tau_ca_boyle",
 "f_timeCourse_t_ca_boyle",
 "f_steadyState_x_ca_boyle",
 "f_rateScale_ca_boyle",
 "f_fcond_ca_boyle",
 "f_inf_ca_boyle",
 "f_tauUnscaled_ca_boyle",
 "f_tau_ca_boyle",
 "h_rateScale_ca_boyle",
 "h_inf_ca_boyle",
 "h_tau_ca_boyle",
 "h_q_ca_boyle",
 "h_fcond_ca_boyle",
 "conductanceScale_ca_boyle",
 "fopen0_ca_boyle",
 "fopen_ca_boyle",
 "g_ca_boyle",
 0,
 "e_q_ca_boyle",
 "f_q_ca_boyle",
 0,
 0};
 static Symbol* _ca_sym;
 
 /* Used by NrnProperty */
 static _nrn_mechanism_std_vector<double> _parm_default{
     0, /* gmax */
     1e-05, /* conductance */
     2, /* e_instances */
     0.100027, /* e_timeCourse_tau */
     1, /* e_steadyState_rate */
     -3.3568, /* e_steadyState_midpoint */
     6.74821, /* e_steadyState_scale */
     1, /* f_instances */
     150.88, /* f_timeCourse_tau */
     1, /* f_steadyState_rate */
     25.1815, /* f_steadyState_midpoint */
     -5.03176, /* f_steadyState_scale */
     0.282473, /* h_alpha */
     -1.00056e-08, /* h_k */
     6.41889e-08, /* h_ca_half */
     1, /* h_instances */
     1000, /* h_SEC */
 }; 
 
 
extern Prop* need_memb(Symbol*);
static void nrn_alloc(Prop* _prop) {
  Prop *prop_ion{};
  Datum *_ppvar{};
   _ppvar = nrn_prop_datum_alloc(_mechtype, 5, _prop);
    _nrn_mechanism_access_dparam(_prop) = _ppvar;
     _nrn_mechanism_cache_instance _ml_real{_prop};
    auto* const _ml = &_ml_real;
    size_t const _iml{};
    assert(_nrn_mechanism_get_num_vars(_prop) == 55);
 	/*initialize range parameters*/
 	gmax = _parm_default[0]; /* 0 */
 	conductance = _parm_default[1]; /* 1e-05 */
 	e_instances = _parm_default[2]; /* 2 */
 	e_timeCourse_tau = _parm_default[3]; /* 0.100027 */
 	e_steadyState_rate = _parm_default[4]; /* 1 */
 	e_steadyState_midpoint = _parm_default[5]; /* -3.3568 */
 	e_steadyState_scale = _parm_default[6]; /* 6.74821 */
 	f_instances = _parm_default[7]; /* 1 */
 	f_timeCourse_tau = _parm_default[8]; /* 150.88 */
 	f_steadyState_rate = _parm_default[9]; /* 1 */
 	f_steadyState_midpoint = _parm_default[10]; /* 25.1815 */
 	f_steadyState_scale = _parm_default[11]; /* -5.03176 */
 	h_alpha = _parm_default[12]; /* 0.282473 */
 	h_k = _parm_default[13]; /* -1.00056e-08 */
 	h_ca_half = _parm_default[14]; /* 6.41889e-08 */
 	h_instances = _parm_default[15]; /* 1 */
 	h_SEC = _parm_default[16]; /* 1000 */
 	 assert(_nrn_mechanism_get_num_vars(_prop) == 55);
 	_nrn_mechanism_access_dparam(_prop) = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_ca_sym);
 nrn_promote(prop_ion, 1, 0);
 	_ppvar[0] = _nrn_mechanism_get_param_handle(prop_ion, 1); /* cai */
 	_ppvar[1] = _nrn_mechanism_get_param_handle(prop_ion, 2); /* cao */
 	_ppvar[2] = _nrn_mechanism_get_param_handle(prop_ion, 3); /* ica */
 	_ppvar[3] = _nrn_mechanism_get_param_handle(prop_ion, 4); /* _ion_dicadv */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 {0, 0}
};
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*)(Datum*));
void _nrn_thread_table_reg(int, nrn_thread_table_check_t);
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 extern "C" void _ca_boyle_reg() {
	int _vectorized = 1;
  _initlists();
 	ion_reg("ca", 2.0);
 	_ca_sym = hoc_lookup("ca_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 1);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
 hoc_register_parm_default(_mechtype, &_parm_default);
         hoc_register_npy_direct(_mechtype, npy_direct_func_proc);
     _nrn_setdata_reg(_mechtype, _setdata);
 #if NMODL_TEXT
  register_nmodl_text_and_filename(_mechtype);
#endif
   _nrn_mechanism_register_data_fields(_mechtype,
                                       _nrn_mechanism_field<double>{"gmax"} /* 0 */,
                                       _nrn_mechanism_field<double>{"conductance"} /* 1 */,
                                       _nrn_mechanism_field<double>{"e_instances"} /* 2 */,
                                       _nrn_mechanism_field<double>{"e_timeCourse_tau"} /* 3 */,
                                       _nrn_mechanism_field<double>{"e_steadyState_rate"} /* 4 */,
                                       _nrn_mechanism_field<double>{"e_steadyState_midpoint"} /* 5 */,
                                       _nrn_mechanism_field<double>{"e_steadyState_scale"} /* 6 */,
                                       _nrn_mechanism_field<double>{"f_instances"} /* 7 */,
                                       _nrn_mechanism_field<double>{"f_timeCourse_tau"} /* 8 */,
                                       _nrn_mechanism_field<double>{"f_steadyState_rate"} /* 9 */,
                                       _nrn_mechanism_field<double>{"f_steadyState_midpoint"} /* 10 */,
                                       _nrn_mechanism_field<double>{"f_steadyState_scale"} /* 11 */,
                                       _nrn_mechanism_field<double>{"h_alpha"} /* 12 */,
                                       _nrn_mechanism_field<double>{"h_k"} /* 13 */,
                                       _nrn_mechanism_field<double>{"h_ca_half"} /* 14 */,
                                       _nrn_mechanism_field<double>{"h_instances"} /* 15 */,
                                       _nrn_mechanism_field<double>{"h_SEC"} /* 16 */,
                                       _nrn_mechanism_field<double>{"gion"} /* 17 */,
                                       _nrn_mechanism_field<double>{"i__ca_boyle"} /* 18 */,
                                       _nrn_mechanism_field<double>{"e_timeCourse_t"} /* 19 */,
                                       _nrn_mechanism_field<double>{"e_steadyState_x"} /* 20 */,
                                       _nrn_mechanism_field<double>{"e_rateScale"} /* 21 */,
                                       _nrn_mechanism_field<double>{"e_fcond"} /* 22 */,
                                       _nrn_mechanism_field<double>{"e_inf"} /* 23 */,
                                       _nrn_mechanism_field<double>{"e_tauUnscaled"} /* 24 */,
                                       _nrn_mechanism_field<double>{"e_tau"} /* 25 */,
                                       _nrn_mechanism_field<double>{"f_timeCourse_t"} /* 26 */,
                                       _nrn_mechanism_field<double>{"f_steadyState_x"} /* 27 */,
                                       _nrn_mechanism_field<double>{"f_rateScale"} /* 28 */,
                                       _nrn_mechanism_field<double>{"f_fcond"} /* 29 */,
                                       _nrn_mechanism_field<double>{"f_inf"} /* 30 */,
                                       _nrn_mechanism_field<double>{"f_tauUnscaled"} /* 31 */,
                                       _nrn_mechanism_field<double>{"f_tau"} /* 32 */,
                                       _nrn_mechanism_field<double>{"h_rateScale"} /* 33 */,
                                       _nrn_mechanism_field<double>{"h_inf"} /* 34 */,
                                       _nrn_mechanism_field<double>{"h_tau"} /* 35 */,
                                       _nrn_mechanism_field<double>{"h_q"} /* 36 */,
                                       _nrn_mechanism_field<double>{"h_fcond"} /* 37 */,
                                       _nrn_mechanism_field<double>{"conductanceScale"} /* 38 */,
                                       _nrn_mechanism_field<double>{"fopen0"} /* 39 */,
                                       _nrn_mechanism_field<double>{"fopen"} /* 40 */,
                                       _nrn_mechanism_field<double>{"g"} /* 41 */,
                                       _nrn_mechanism_field<double>{"e_q"} /* 42 */,
                                       _nrn_mechanism_field<double>{"f_q"} /* 43 */,
                                       _nrn_mechanism_field<double>{"temperature"} /* 44 */,
                                       _nrn_mechanism_field<double>{"eca"} /* 45 */,
                                       _nrn_mechanism_field<double>{"ica"} /* 46 */,
                                       _nrn_mechanism_field<double>{"cai"} /* 47 */,
                                       _nrn_mechanism_field<double>{"cao"} /* 48 */,
                                       _nrn_mechanism_field<double>{"rate_e_q"} /* 49 */,
                                       _nrn_mechanism_field<double>{"rate_f_q"} /* 50 */,
                                       _nrn_mechanism_field<double>{"De_q"} /* 51 */,
                                       _nrn_mechanism_field<double>{"Df_q"} /* 52 */,
                                       _nrn_mechanism_field<double>{"v"} /* 53 */,
                                       _nrn_mechanism_field<double>{"_g"} /* 54 */,
                                       _nrn_mechanism_field<double*>{"_ion_cai", "ca_ion"} /* 0 */,
                                       _nrn_mechanism_field<double*>{"_ion_cao", "ca_ion"} /* 1 */,
                                       _nrn_mechanism_field<double*>{"_ion_ica", "ca_ion"} /* 2 */,
                                       _nrn_mechanism_field<double*>{"_ion_dicadv", "ca_ion"} /* 3 */,
                                       _nrn_mechanism_field<int>{"_cvode_ieq", "cvodeieq"} /* 4 */);
  hoc_register_prop_size(_mechtype, 55, 5);
  hoc_register_dparam_semantics(_mechtype, 0, "ca_ion");
  hoc_register_dparam_semantics(_mechtype, 1, "ca_ion");
  hoc_register_dparam_semantics(_mechtype, 2, "ca_ion");
  hoc_register_dparam_semantics(_mechtype, 3, "ca_ion");
  hoc_register_dparam_semantics(_mechtype, 4, "cvodeieq");
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 
    hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 ca_boyle /Users/zzz/Desktop/软体线虫/results/full302-operating-range-2026-11-07/kernels-direct-cnexp/ca_boyle.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
static int _reset;
static const char *modelname = "Mod file for component: Component(id=ca_boyle type=ionChannelHH)";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int rates(_internalthreadargsproto_);
 
static int _ode_spec1(_internalthreadargsproto_);
/*static int _ode_matsol1(_internalthreadargsproto_);*/
 static neuron::container::field_index _slist1[2], _dlist1[2];
 static int states(_internalthreadargsproto_);
 
/*CVODE*/
 static int _ode_spec1 (_internalthreadargsproto_) {int _reset = 0; {
   rates ( _threadargs_ ) ;
   De_q = rate_e_q ;
   Df_q = rate_f_q ;
   }
 return _reset;
}
 static int _ode_matsol1 (_internalthreadargsproto_) {
 rates ( _threadargs_ ) ;
 De_q = De_q  / (1. - dt*( 0.0 )) ;
 Df_q = Df_q  / (1. - dt*( 0.0 )) ;
  return 0;
}
 /*END CVODE*/
 static int states (_internalthreadargsproto_) { {
   rates ( _threadargs_ ) ;
    e_q = e_q - dt*(- ( rate_e_q ) ) ;
    f_q = f_q - dt*(- ( rate_f_q ) ) ;
   }
  return 0;
}
 
static int  rates ( _internalthreadargsproto_ ) {
   double _lcaConc ;
 _lcaConc = cai ;
   e_timeCourse_t = e_timeCourse_tau ;
   e_steadyState_x = e_steadyState_rate / ( 1.0 + exp ( 0.0 - ( v - e_steadyState_midpoint ) / e_steadyState_scale ) ) ;
   e_rateScale = 1.0 ;
   e_fcond = pow( e_q , e_instances ) ;
   e_inf = e_steadyState_x ;
   e_tauUnscaled = e_timeCourse_t ;
   e_tau = e_tauUnscaled / e_rateScale ;
   f_timeCourse_t = f_timeCourse_tau ;
   f_steadyState_x = f_steadyState_rate / ( 1.0 + exp ( 0.0 - ( v - f_steadyState_midpoint ) / f_steadyState_scale ) ) ;
   f_rateScale = 1.0 ;
   f_fcond = pow( f_q , f_instances ) ;
   f_inf = f_steadyState_x ;
   f_tauUnscaled = f_timeCourse_t ;
   f_tau = f_tauUnscaled / f_rateScale ;
   h_rateScale = 1.0 ;
   h_inf = 1.0 / ( 1.0 + ( exp ( ( h_ca_half - _lcaConc ) / h_k ) ) ) ;
   h_tau = 0.0 * h_SEC ;
   h_q = h_inf ;
   h_fcond = 1.0 + ( ( h_q - 1.0 ) * h_alpha ) ;
   rate_e_q = ( e_inf - e_q ) / e_tau ;
   rate_f_q = ( f_inf - f_q ) / f_tau ;
    return 0; }
 
static void _hoc_rates(void) {
  double _r;
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 
  if(!_prop_id) {
    hoc_execerror("No data for rates_ca_boyle. Requires prior call to setdata_ca_boyle and that the specified mechanism instance still be in existence.", NULL);
  }
  Prop* _local_prop = _extcall_prop;
  _nrn_mechanism_cache_instance _ml_real{_local_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _local_prop ? _nrn_mechanism_access_dparam(_local_prop) : nullptr;
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r = 1.;
 rates ( _threadargs_ );
 hoc_retpushx(_r);
}
 
static double _npy_rates(Prop* _prop) {
    double _r{0.0};
 Datum* _ppvar; Datum* _thread; NrnThread* _nt;
 _nrn_mechanism_cache_instance _ml_real{_prop};
auto* const _ml = &_ml_real;
size_t const _iml{};
_ppvar = _nrn_mechanism_access_dparam(_prop);
_thread = _extcall_thread.data();
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
_nt = nrn_threads;
 _r = 1.;
 rates ( _threadargs_ );
 return(_r);
}
 
static int _ode_count(int _type){ return 2;}
 
static void _ode_spec(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
   Datum* _ppvar;
   size_t _iml;   _nrn_mechanism_cache_range* _ml;   Node* _nd{};
  double _v{};
  int _cntml;
  _nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
  _ml = &_lmr;
  _cntml = _ml_arg->_nodecount;
  Datum *_thread{_ml_arg->_thread};
  double* _globals = nullptr;
  if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _ppvar = _ml_arg->_pdata[_iml];
    _nd = _ml_arg->_nodelist[_iml];
    v = NODEV(_nd);
  cai = _ion_cai;
  cao = _ion_cao;
     _ode_spec1 (_threadargs_);
  }}
 
static void _ode_map(Prop* _prop, int _ieq, neuron::container::data_handle<double>* _pv, neuron::container::data_handle<double>* _pvdot, double* _atol, int _type) { 
  Datum* _ppvar;
  _ppvar = _nrn_mechanism_access_dparam(_prop);
  _cvode_ieq = _ieq;
  for (int _i=0; _i < 2; ++_i) {
    _pv[_i] = _nrn_mechanism_get_param_handle(_prop, _slist1[_i]);
    _pvdot[_i] = _nrn_mechanism_get_param_handle(_prop, _dlist1[_i]);
    _cvode_abstol(_atollist, _atol, _i);
  }
 }
 
static void _ode_matsol_instance1(_internalthreadargsproto_) {
 _ode_matsol1 (_threadargs_);
 }
 
static void _ode_matsol(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
   Datum* _ppvar;
   size_t _iml;   _nrn_mechanism_cache_range* _ml;   Node* _nd{};
  double _v{};
  int _cntml;
  _nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
  _ml = &_lmr;
  _cntml = _ml_arg->_nodecount;
  Datum *_thread{_ml_arg->_thread};
  double* _globals = nullptr;
  if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _ppvar = _ml_arg->_pdata[_iml];
    _nd = _ml_arg->_nodelist[_iml];
    v = NODEV(_nd);
  cai = _ion_cai;
  cao = _ion_cao;
 _ode_matsol_instance1(_threadargs_);
 }}

static void initmodel(_internalthreadargsproto_) {
  int _i; double _save;{
  e_q = e_q0;
  f_q = f_q0;
 {
   eca = 40.0 ;
   temperature = celsius + 273.15 ;
   rates ( _threadargs_ ) ;
   rates ( _threadargs_ ) ;
   e_q = e_inf ;
   f_q = f_inf ;
   }
 
}
}

static void nrn_init(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type){
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto* const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
   _v = _vec_v[_ni[_iml]];
 v = _v;
  cai = _ion_cai;
  cao = _ion_cao;
 initmodel(_threadargs_);
 }
}

static double _nrn_current(_internalthreadargsprotocomma_ double _v) {
double _current=0.; v=_v;
{ {
   conductanceScale = 1.0 ;
   fopen0 = e_fcond * f_fcond * h_fcond ;
   fopen = conductanceScale * fopen0 ;
   g = conductance * fopen ;
   gion = gmax * fopen ;
   ica = gion * ( v - eca ) ;
   i__ca_boyle = - 1.0 * ica ;
   }
 _current += ica;

} return _current;
}

static void nrn_cur(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto const _vec_rhs = _nt->node_rhs_storage();
auto const _vec_sav_rhs = _nt->node_sav_rhs_storage();
auto const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
   _v = _vec_v[_ni[_iml]];
  cai = _ion_cai;
  cao = _ion_cao;
 auto const _g_local = _nrn_current(_threadargscomma_ _v + .001);
 	{ double _dica;
  _dica = ica;
 _rhs = _nrn_current(_threadargscomma_ _v);
  _ion_dicadv += (_dica - ica)/.001 ;
 	}
 _g = (_g_local - _rhs)/.001;
  _ion_ica += ica ;
	 _vec_rhs[_ni[_iml]] -= _rhs;
 
}
 
}

static void nrn_jacob(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto const _vec_d = _nt->node_d_storage();
auto const _vec_sav_d = _nt->node_sav_d_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; int* _ni; int _iml, _cntml;
_ni = _ml_arg->_nodeindices;
_cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (_iml = 0; _iml < _cntml; ++_iml) {
  _vec_d[_ni[_iml]] += _g;
 
}
 
}

static void nrn_state(_nrn_model_sorted_token const& _sorted_token, NrnThread* _nt, Memb_list* _ml_arg, int _type) {
_nrn_mechanism_cache_range _lmr{_sorted_token, *_nt, *_ml_arg, _type};
auto* const _vec_v = _nt->node_voltage_storage();
auto* const _ml = &_lmr;
Datum* _ppvar; Datum* _thread;
Node *_nd; double _v = 0.0; int* _ni;
_ni = _ml_arg->_nodeindices;
size_t _cntml = _ml_arg->_nodecount;
_thread = _ml_arg->_thread;
double* _globals = nullptr;
if (gind != 0 && _thread != nullptr) { _globals = _thread[_gth].get<double*>(); }
for (size_t _iml = 0; _iml < _cntml; ++_iml) {
 _ppvar = _ml_arg->_pdata[_iml];
 _nd = _ml_arg->_nodelist[_iml];
   _v = _vec_v[_ni[_iml]];
 v=_v;
{
  cai = _ion_cai;
  cao = _ion_cao;
 {   states(_threadargs_);
  } }}

}

static void terminal(){}

static void _initlists(){
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = {e_q_columnindex, 0};  _dlist1[0] = {De_q_columnindex, 0};
 _slist1[1] = {f_q_columnindex, 0};  _dlist1[1] = {Df_q_columnindex, 0};
_first = 0;
}

#if NMODL_TEXT
static void register_nmodl_text_and_filename(int mech_type) {
    const char* nmodl_filename = "/Users/zzz/Desktop/软体线虫/results/full302-operating-range-2026-11-07/kernels-direct-cnexp/ca_boyle.mod";
    const char* nmodl_file_text = 
  "TITLE Mod file for component: Component(id=ca_boyle type=ionChannelHH)\n"
  "\n"
  "COMMENT\n"
  "\n"
  "    This NEURON file has been generated by org.neuroml.export (see https://github.com/NeuroML/org.neuroml.export)\n"
  "         org.neuroml.export  v1.11.0\n"
  "         org.neuroml.model   v1.11.0\n"
  "         jLEMS               v0.12.0\n"
  "\n"
  "ENDCOMMENT\n"
  "\n"
  "NEURON {\n"
  "    SUFFIX ca_boyle\n"
  "    USEION ca READ cai,cao WRITE ica VALENCE 2 ? Assuming valence = 2 (Ca ion); TODO check this!!\n"
  "    \n"
  "    RANGE gion\n"
  "    RANGE i__ca_boyle : a copy of the variable for current which makes it easier to access from outside the mod file\n"
  "    RANGE gmax                              : Will be changed when ion channel mechanism placed on cell!\n"
  "    RANGE conductance                       : parameter\n"
  "    RANGE g                                 : exposure\n"
  "    RANGE fopen                             : exposure\n"
  "    RANGE e_instances                       : parameter\n"
  "    RANGE e_tau                             : exposure\n"
  "    RANGE e_inf                             : exposure\n"
  "    RANGE e_rateScale                       : exposure\n"
  "    RANGE e_fcond                           : exposure\n"
  "    RANGE e_timeCourse_tau                  : parameter\n"
  "    RANGE e_timeCourse_t                    : exposure\n"
  "    RANGE e_steadyState_rate                : parameter\n"
  "    RANGE e_steadyState_midpoint            : parameter\n"
  "    RANGE e_steadyState_scale               : parameter\n"
  "    RANGE e_steadyState_x                   : exposure\n"
  "    RANGE f_instances                       : parameter\n"
  "    RANGE f_tau                             : exposure\n"
  "    RANGE f_inf                             : exposure\n"
  "    RANGE f_rateScale                       : exposure\n"
  "    RANGE f_fcond                           : exposure\n"
  "    RANGE f_timeCourse_tau                  : parameter\n"
  "    RANGE f_timeCourse_t                    : exposure\n"
  "    RANGE f_steadyState_rate                : parameter\n"
  "    RANGE f_steadyState_midpoint            : parameter\n"
  "    RANGE f_steadyState_scale               : parameter\n"
  "    RANGE f_steadyState_x                   : exposure\n"
  "    RANGE h_alpha                           : parameter\n"
  "    RANGE h_k                               : parameter\n"
  "    RANGE h_ca_half                         : parameter\n"
  "    RANGE h_instances                       : parameter\n"
  "    RANGE h_SEC                             : parameter\n"
  "    RANGE h_tau                             : exposure\n"
  "    RANGE h_inf                             : exposure\n"
  "    RANGE h_rateScale                       : exposure\n"
  "    RANGE h_fcond                           : exposure\n"
  "    RANGE h_q                               : exposure\n"
  "    RANGE e_tauUnscaled                     : derived variable\n"
  "    RANGE f_tauUnscaled                     : derived variable\n"
  "    RANGE conductanceScale                  : derived variable\n"
  "    RANGE fopen0                            : derived variable\n"
  "    \n"
  "}\n"
  "\n"
  "UNITS {\n"
  "    \n"
  "    (nA) = (nanoamp)\n"
  "    (uA) = (microamp)\n"
  "    (mA) = (milliamp)\n"
  "    (A) = (amp)\n"
  "    (mV) = (millivolt)\n"
  "    (mS) = (millisiemens)\n"
  "    (uS) = (microsiemens)\n"
  "    (nF) = (nanofarad)\n"
  "    (molar) = (1/liter)\n"
  "    (kHz) = (kilohertz)\n"
  "    (mM) = (millimolar)\n"
  "    (um) = (micrometer)\n"
  "    (umol) = (micromole)\n"
  "    (pC) = (picocoulomb)\n"
  "    (S) = (siemens)\n"
  "    \n"
  "}\n"
  "\n"
  "PARAMETER {\n"
  "    \n"
  "    gmax = 0  (S/cm2)                       : Will be changed when ion channel mechanism placed on cell!\n"
  "    \n"
  "    conductance = 1.0E-5 (uS)              : was: 1.0E-11 (conductance)\n"
  "    e_instances = 2                        : was: 2.0 (none)\n"
  "    e_timeCourse_tau = 0.100027 (ms)       : was: 1.0002700000000001E-4 (time)\n"
  "    e_steadyState_rate = 1                 : was: 1.0 (none)\n"
  "    e_steadyState_midpoint = -3.3568 (mV)  : was: -0.0033568 (voltage)\n"
  "    e_steadyState_scale = 6.74821 (mV)     : was: 0.00674821 (voltage)\n"
  "    f_instances = 1                        : was: 1.0 (none)\n"
  "    f_timeCourse_tau = 150.88 (ms)         : was: 0.15088 (time)\n"
  "    f_steadyState_rate = 1                 : was: 1.0 (none)\n"
  "    f_steadyState_midpoint = 25.1815 (mV)  : was: 0.0251815 (voltage)\n"
  "    f_steadyState_scale = -5.03176 (mV)    : was: -0.005031760000000001 (voltage)\n"
  "    h_alpha = 0.282473                     : was: 0.282473 (none)\n"
  "    h_k = -1.00056E-8 (mM)                 : was: -1.00056E-8 (concentration)\n"
  "    h_ca_half = 6.41889E-8 (mM)            : was: 6.41889E-8 (concentration)\n"
  "    h_instances = 1                        : was: 1.0 (none)\n"
  "    h_SEC = 1000 (ms)                      : was: 1.0 (time)\n"
  "}\n"
  "\n"
  "ASSIGNED {\n"
  "    \n"
  "    gion   (S/cm2)                          : Transient conductance density of the channel? Standard Assigned variables with ionChannel\n"
  "    v (mV)\n"
  "    celsius (degC)\n"
  "    temperature (K)\n"
  "    eca (mV)\n"
  "    ica (mA/cm2)\n"
  "    i__ca_boyle (mA/cm2)\n"
  "    \n"
  "    cai (mM)\n"
  "    \n"
  "    cao (mM)\n"
  "    \n"
  "    e_timeCourse_t (ms)                     : derived variable\n"
  "    e_steadyState_x                         : derived variable\n"
  "    e_rateScale                             : derived variable\n"
  "    e_fcond                                 : derived variable\n"
  "    e_inf                                   : derived variable\n"
  "    e_tauUnscaled (ms)                      : derived variable\n"
  "    e_tau (ms)                              : derived variable\n"
  "    f_timeCourse_t (ms)                     : derived variable\n"
  "    f_steadyState_x                         : derived variable\n"
  "    f_rateScale                             : derived variable\n"
  "    f_fcond                                 : derived variable\n"
  "    f_inf                                   : derived variable\n"
  "    f_tauUnscaled (ms)                      : derived variable\n"
  "    f_tau (ms)                              : derived variable\n"
  "    h_rateScale                             : derived variable\n"
  "    h_inf                                   : derived variable\n"
  "    h_tau (ms)                              : derived variable\n"
  "    h_q                                     : derived variable\n"
  "    h_fcond                                 : derived variable\n"
  "    conductanceScale                        : derived variable\n"
  "    fopen0                                  : derived variable\n"
  "    fopen                                   : derived variable\n"
  "    g (uS)                                  : derived variable\n"
  "    rate_e_q (/ms)\n"
  "    rate_f_q (/ms)\n"
  "    \n"
  "}\n"
  "\n"
  "STATE {\n"
  "    e_q  : dimension: none\n"
  "    f_q  : dimension: none\n"
  "    \n"
  "}\n"
  "\n"
  "INITIAL {\n"
  "    eca = 40.0\n"
  "    \n"
  "    temperature = celsius + 273.15\n"
  "    \n"
  "    rates()\n"
  "    rates() ? To ensure correct initialisation.\n"
  "    \n"
  "    e_q = e_inf\n"
  "    \n"
  "    f_q = f_inf\n"
  "    \n"
  "}\n"
  "\n"
  "BREAKPOINT {\n"
  "    \n"
  "    SOLVE states METHOD cnexp\n"
  "    \n"
  "    ? DerivedVariable is based on path: conductanceScaling[*]/factor, on: Component(id=ca_boyle type=ionChannelHH), from conductanceScaling; null\n"
  "    ? Path not present in component, using factor: 1\n"
  "    \n"
  "    conductanceScale = 1 \n"
  "    \n"
  "    ? DerivedVariable is based on path: gates[*]/fcond, on: Component(id=ca_boyle type=ionChannelHH), from gates; Component(id=e type=gateHHtauInf)\n"
  "    ? multiply applied to all instances of fcond in: <gates> ([Component(id=e type=gateHHtauInf), Component(id=f type=gateHHtauInf), Component(id=h type=customHGate)]))\n"
  "    fopen0 = e_fcond * f_fcond * h_fcond ? path based, prefix = \n"
  "    \n"
  "    fopen = conductanceScale  *  fopen0 ? evaluable\n"
  "    g = conductance  *  fopen ? evaluable\n"
  "    gion = gmax * fopen \n"
  "    \n"
  "    ica = gion * (v - eca)\n"
  "    i__ca_boyle =  -1 * ica : set this variable to the current also - note -1 as channel current convention for LEMS used!\n"
  "    \n"
  "}\n"
  "\n"
  "DERIVATIVE states {\n"
  "    rates()\n"
  "    e_q' = rate_e_q \n"
  "    f_q' = rate_f_q \n"
  "    \n"
  "}\n"
  "\n"
  "PROCEDURE rates() {\n"
  "    LOCAL caConc\n"
  "    \n"
  "    caConc = cai\n"
  "    \n"
  "    e_timeCourse_t = e_timeCourse_tau ? evaluable\n"
  "    e_steadyState_x = e_steadyState_rate  / (1 + exp(0 - (v -  e_steadyState_midpoint )/ e_steadyState_scale )) ? evaluable\n"
  "    ? DerivedVariable is based on path: q10Settings[*]/q10, on: Component(id=e type=gateHHtauInf), from q10Settings; null\n"
  "    ? Path not present in component, using factor: 1\n"
  "    \n"
  "    e_rateScale = 1 \n"
  "    \n"
  "    e_fcond = e_q ^ e_instances ? evaluable\n"
  "    ? DerivedVariable is based on path: steadyState/x, on: Component(id=e type=gateHHtauInf), from steadyState; Component(id=null type=HHSigmoidVariable)\n"
  "    e_inf = e_steadyState_x ? path based, prefix = e_\n"
  "    \n"
  "    ? DerivedVariable is based on path: timeCourse/t, on: Component(id=e type=gateHHtauInf), from timeCourse; Component(id=null type=fixedTimeCourse)\n"
  "    e_tauUnscaled = e_timeCourse_t ? path based, prefix = e_\n"
  "    \n"
  "    e_tau = e_tauUnscaled  /  e_rateScale ? evaluable\n"
  "    f_timeCourse_t = f_timeCourse_tau ? evaluable\n"
  "    f_steadyState_x = f_steadyState_rate  / (1 + exp(0 - (v -  f_steadyState_midpoint )/ f_steadyState_scale )) ? evaluable\n"
  "    ? DerivedVariable is based on path: q10Settings[*]/q10, on: Component(id=f type=gateHHtauInf), from q10Settings; null\n"
  "    ? Path not present in component, using factor: 1\n"
  "    \n"
  "    f_rateScale = 1 \n"
  "    \n"
  "    f_fcond = f_q ^ f_instances ? evaluable\n"
  "    ? DerivedVariable is based on path: steadyState/x, on: Component(id=f type=gateHHtauInf), from steadyState; Component(id=null type=HHSigmoidVariable)\n"
  "    f_inf = f_steadyState_x ? path based, prefix = f_\n"
  "    \n"
  "    ? DerivedVariable is based on path: timeCourse/t, on: Component(id=f type=gateHHtauInf), from timeCourse; Component(id=null type=fixedTimeCourse)\n"
  "    f_tauUnscaled = f_timeCourse_t ? path based, prefix = f_\n"
  "    \n"
  "    f_tau = f_tauUnscaled  /  f_rateScale ? evaluable\n"
  "    h_rateScale = 1 ? evaluable\n"
  "    h_inf = 1 / (1 + (exp( ( h_ca_half  - caConc) /  h_k ))) ? evaluable\n"
  "    h_tau = 0 *  h_SEC ? evaluable\n"
  "    h_q = h_inf ? evaluable\n"
  "    h_fcond = 1 +(( h_q -1) *  h_alpha ) ? evaluable\n"
  "    \n"
  "     \n"
  "    rate_e_q = ( e_inf  -  e_q ) /  e_tau ? Note units of all quantities used here need to be consistent!\n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    rate_f_q = ( f_inf  -  f_q ) /  f_tau ? Note units of all quantities used here need to be consistent!\n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    \n"
  "     \n"
  "    \n"
  "}\n"
  "\n"
  ;
    hoc_reg_nmodl_filename(mech_type, nmodl_filename);
    hoc_reg_nmodl_text(mech_type, nmodl_file_text);
}
#endif
