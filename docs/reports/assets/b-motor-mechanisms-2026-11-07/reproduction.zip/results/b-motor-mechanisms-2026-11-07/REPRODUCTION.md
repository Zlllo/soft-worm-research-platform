# 阶段暂停与复现

本阶段按用户要求暂停，所有已启动仿真已结束。没有启动身体扰动、反馈重放、新身体分支的步长减半或训练。

只重算保存数据的汇总（无需NEURON或身体程序）：

```sh
python analysis/neuromechanics/summarize_b_motor_stage.py
```

需要NumPy与SciPy；完整环境版本保存在同目录`requirements.txt`。`MANIFEST.json`是逐文件SHA256。包外`archive-validation.json`记录CRC、逐文件哈希和独立解压后的汇总逐字节一致；归档检查不会再运行新的仿真。

当前完整网络条件保存在`prototype_*`、`calcium0_8`、`generic_C1_8`及`nmj9_*`目录。9个条件共用302节点连接计划，18个B原型与其余284个C1神经元、95个C1肌肉细胞一起积分；B原型在`kernels/BMotorPoint.mod`，参数在`selected-parameters.json`。`runtime/src`与`runtime/data`是可独立导入的运行快照。原模型及此前归档没有被覆盖。

候选校准包括`isolated`、`narrow-gates`、`lower-calcium`三个系列。9个未通过的候选也保留；最终参数按孤立细胞标准选择，没有按身体速度挑选。`component-dt*`保存独立NEURON/SciPy验证；`bifurcation`保存固定点及时间积分；`nmj-*nS`保存相同神经波形下的肌肉传递试验。

恢复工作时先读取报告和`stage-pause.json`。优先安排新完整身体分支的步长复查及身体扰动／冻结反馈重放，不能把本轮实时反馈与关闭反馈的差别当成已验证的相位牵引或适应优势。

如以后明确恢复并重跑，使用新的条件名保护现有结果，设置`PYTHONPATH=results/b-motor-mechanisms-2026-11-07/runtime/src`。macOS arm64二进制需NEURON9.0.2，解压后恢复身体`worker`可执行权限；其他平台从源码重建。C1、Sundials及连接数据许可随`licenses`与`runtime/data`保留，身体原始版权与引用要求保留于C++文件头。
