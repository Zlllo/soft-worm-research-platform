# Reproduce the persistent-body interface

The ZIP is a source/data snapshot, without native binaries. It contains the selected build-v2 source and a superseded first implementation in evidence/build. All source use notices must be retained. The original body is for research, teaching and other noncommercial use; cite Boyle, Berri & Cohen (2012), DOI 10.3389/fncom.2012.00010. See upstream-reference and the source lock.

From an extracted archive root, provide Python with numpy and pytest; matplotlib is needed for plotting, and torch for the 7 existing connectome regression checks. The verification.json evidence records the tested interpreter/package versions. Native g++, make and a working build toolchain are needed. Rebuilding on other systems is not verified here.

Clone https://github.com/OpenSourceBrain/CelegansNeuromechanicalGaitModulation.git into upstream/boyle2012 and checkout 1f825daff066d56e5c26384d71648914ca169d6b. Build its bundled dependency with:

```bash
python3 analysis/neuromechanics/build_boyle_source.py --source upstream/boyle2012 --output local-dependency-build
python3 analysis/neuromechanics/build_boyle_worker.py --source upstream/boyle2012 --output local-worker
BOYLE_WORKER="$PWD/local-worker/worker" PYTHONPATH=src python3 -m pytest tests/test_boyle_body.py tests/test_boyle_output.py tests/test_neuromechanics_mapping.py tests/test_connectome.py -q
PYTHONPATH=src MPLCONFIGDIR=/tmp/worm-matplotlib python3 analysis/neuromechanics/audit_boyle_worker.py --binary local-worker/worker --output local-audit --previous previous-accepted-state
```

Output directories must not already exist. Compare local-audit/summary.json and traces against evidence/audit. Wall times are machine-specific; the compatibility comparison preserves solver lookahead only for source reproduction. Default new runs cap solver time at each physical update.

The native protocol has 681 finite numeric values after OK: time, microstep count, internal IDA time, 147 poses, 147 derivatives, then 96 each neural outputs, muscles, stretch inputs and side lengths. Positions are m, time s, rod angles rad. STEP n drive bias holds controls for n microsteps. New controls affect the muscle update after the next physical interval. GET returns a snapshot; QUIT releases the worker. Python exposes a restricted thermal observation; no trained thermotaxis controller is included.
